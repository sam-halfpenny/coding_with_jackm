print ('hello world')
